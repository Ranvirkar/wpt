﻿namespace EmployeeApplication.Services
{
    public interface IService
    {
        bool Login(string email, string password);
    }
}
