﻿namespace EmployeeApplication.Repositories
{
    public interface IManager
    {
        bool Login(string email, string password);
    }
}
