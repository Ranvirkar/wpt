﻿using Studentwebapi.Entity;

namespace Studentwebapi.repository
{
    public interface istudentrepo
    {
        public List<Student> GetStudents();
        public void deletebyid(int id);
       
         public Student searchbyid(int id);
           public List<Student> sortbyname();
        public void insert(Student student);

        public void update(Student student);
       public Student getstudentbyemailandphone(string email,string phone);
        public void updatestudentdetails(string email,string phone);
        




    }
}
