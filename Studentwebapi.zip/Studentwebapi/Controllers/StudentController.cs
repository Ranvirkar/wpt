﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Studentwebapi.service;
using Studentwebapi.Entity;

namespace Studentwebapi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StudentController : ControllerBase
    {
        public istudentservice service;
        public StudentController(istudentservice service)
        {
            this.service = service;
        }
        [HttpGet]
        public IActionResult getall()
        {
            List<Student> list = service.GetStudents();
            return Ok(list);
        }
        [HttpDelete]
        public void delete(int id)
        {
            service.deletebyid(id);
        }
        [HttpGet]
        [Route("shop/abc")]
        public IActionResult get(int id)
        {
            Student student = service.searchbyid(id);
            return Ok(student);
        }
        [HttpGet]
        [Route("shop")]
        public IActionResult sortbyname()
        {
            return Ok(service.sortbyname());
        }
        [HttpPost]
        public void insert(Student student)
        {
            service.insert(student);
        }
        [HttpPut]
        public void update(Student student)
        {
            service.update(student);
        }
        [HttpGet]
        [Route("shop/abcpqr")]


        public IActionResult getstudentbyemailandphone(string email, string phone)
        {
            Console.WriteLine("email" + email + "phone" + phone + "in controller");
            return Ok(service.getstudentbyemailandphone(email, phone));
        }
        [HttpPut]
        [Route("abc")]
            public void updatestudentdetails(string email,string phone)
        {
            service.updatestudentdetails(email,phone);
        }
    }
}