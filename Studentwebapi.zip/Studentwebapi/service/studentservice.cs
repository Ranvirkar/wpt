﻿using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Mvc;
using Studentwebapi.Entity;
using Studentwebapi.repository;

namespace Studentwebapi.service
{
    public class studentservice:istudentservice
    {
        public List<Student> GetStudents()
        {
        List<Student> student=new List<Student>();
        studentrepo repo=new studentrepo();
       student=repo.GetStudents();
            return student;
        }
        public void deletebyid(int id)
        {
            studentrepo repo=new studentrepo();
            repo.deletebyid(id);
        }
        public Student searchbyid(int id)
        {
            studentrepo repo=new studentrepo();
           return repo.searchbyid(id);
        }
        public List<Student> sortbyname()
        {
            studentrepo repo=new studentrepo();
            List<Student> student=repo.sortbyname();
            return student;
        }
        public void insert(Student student)
        {
            studentrepo repo=new studentrepo();
            repo.insert(student);
        }
        public void update(Student student)
        {
            studentrepo repo=new studentrepo();
            repo.update(student);
        }
       public Student getstudentbyemailandphone(string email, string phone)
        {
            Console.WriteLine("email" + email + "phone" + phone + "in service");
            studentrepo repo= new studentrepo();
            return repo.getstudentbyemailandphone(email, phone);
        }
        public void updatestudentdetails(string email,string phone)
        {
            studentrepo repo=new studentrepo();
            repo.updatestudentdetails(email, phone);
        }

        //return repo.getstudentbyemailandphone(email,phone);
    }

        /*  public void insert(Student student);
          

          public void update(Student student);

          public void sortbyname();*/
    
}
